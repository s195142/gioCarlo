package carlo;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;


public class Carlo {
	
	private static ArrayList<String> elenCarlo;
	private static ArrayList<String> elenCarloXXX;
	private static BufferedReader in;
	
	
	public static void popolaLista() {
		elenCarlo.add("montecarlo");
		elenCarlo.add("caricarlo");
		elenCarlo.add("coricarlo");
		elenCarlo.add("moltiplicarlo");
		elenCarlo.add("marcarlo");
		elenCarlo.add("imbucarlo");
		elenCarlo.add("svaccarlo");
		elenCarlo.add("ubriacarlo");
		elenCarlo.add("masticarlo");
		elenCarlo.add("ubicarlo");
		elenCarlo.add("ammaccarlo");
		elenCarlo.add("orticarlo");
		elenCarlo.add("paracarlo");
		elenCarlo.add("er pizzicarlo");
		elenCarlo.add("tizio carlo e semprone");
		elenCarlo.add("la casa di carlo");
		elenCarlo.add("affumicarlo");
		elenCarlo.add("mancarlo");
		elenCarlo.add("supermercarlo");
		elenCarlo.add("sbancarlo");
		elenCarlo.add("sbiancarlo");
		elenCarlo.add("avvocarlo");
		elenCarlo.add("avocarlo");
		elenCarlo.add("significarlo");
		elenCarlo.add("prevaricarlo");
		elenCarlo.add("carlo");


	}
	
	public static void popolaListaX() {
		elenCarloXXX.add("sucarlo a un pruno");
		elenCarloXXX.add("cavalcarlo");
		elenCarloXXX.add("ficcarlo");

	}
	
	public static void main(String[] args) throws IOException {
		
		in = new BufferedReader(new InputStreamReader(System.in));
		String scelta = "";;
		
		elenCarlo = new ArrayList<String>();
		elenCarloXXX = new ArrayList<String>();
		
		popolaLista();
		popolaListaX();
		
		Random r = new Random();	
		
		do {
			System.out.println("Vuoi un nome normale o un nome XXX?\n1 - normale\n2 - xxx");
			
			scelta = in.readLine();
			
			switch(scelta) {
				case "1":{
					String carlo = scegliCarloACaso();
					System.out.println("Quale sar� il prossimo nome di insta di Carlo?");
//					for(String c : elenCarlo) {
//						System.out.println(elenCarlo.indexOf(c)+") "+c);
//					}
//					System.out.println("Il nome sar�:");
					System.out.println(carlo);
					break;

				}
				case "2":{
					String carlo = scegliCarloXXXACaso();
					System.out.println("Quale sar� il prossimo nome XXX di insta di Carlo?");
//					for(String c : elenCarloXXX) {
//						System.out.println(elenCarloXXX.indexOf(c)+") "+c);
//					}
//					System.out.println("Il nome sar�:");
					System.out.println(carlo);
					break;
				}
			}
		}while(scelta!="0");
			
		
	}
	
	
	public static String scegliCarloACaso() {
		
		Random r = new Random();
		int index = r.nextInt(elenCarlo.size());
		
		return elenCarlo.get(index);
		
	}
	
	public static String scegliCarloXXXACaso() {
		
		Random r = new Random();
		int index = r.nextInt(elenCarloXXX.size());
		
		return elenCarloXXX.get(index);
		
	}

}
